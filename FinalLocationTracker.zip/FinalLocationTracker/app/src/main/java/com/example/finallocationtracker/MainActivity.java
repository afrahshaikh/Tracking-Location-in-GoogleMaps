package com.example.finallocationtracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.sql.Time;
import java.util.Date;

public class MainActivity extends AppCompatActivity {



    RecyclerView recyclerView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main1);


        recyclerView=findViewById(R.id.recycler);


        LinearLayoutManager mgr1=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mgr1);
        mgr1.setOrientation(LinearLayoutManager.VERTICAL);

        CustomAdapter c=new CustomAdapter(getApplicationContext());

        recyclerView.setAdapter(c);
    }
}
