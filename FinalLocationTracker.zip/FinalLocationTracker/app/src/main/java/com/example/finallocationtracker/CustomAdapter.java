package com.example.finallocationtracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    //ArrayList<String> data;
    Context context;
    LayoutInflater inflater;

    public CustomAdapter( Context context) {

        this.context = context;

        inflater=LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=inflater.inflate(R.layout.main,parent,false);

        MyViewHolder vh=new MyViewHolder(v);
        return vh;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
holder.location.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=new Intent(context.getApplicationContext(),MapsActivity.class);
        context.startActivity(i);

    }
});
    }



    @Override
    public int getItemCount() {

        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {

        TextView title, description, date, time;
        CardView cardView;
        Button location;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.title);
            description=itemView.findViewById(R.id.description);
            date=itemView.findViewById(R.id.date);
            cardView=itemView.findViewById(R.id.cardView);
            time=itemView.findViewById(R.id.time);
            location=itemView.findViewById(R.id.locationbutton);



        }
    }
}


